# 五子棋（IntelliJ IDEA / Maven）

两人轮流在棋盘交叉点落子，黑先白后，谁先在横、竖、斜任意方向连成五个（或更多）同色子谁赢。默认 **15×15**。可开启连珠 **禁手**：黑棋不能双三、双四、长连。

窗口顶部可直接切换 **桌面皮肤**：

| 风格 | 说明 | 默认棋子 |
|------|------|----------|
| 古风 | 水墨丹青、木框金线、墨玉棋子 | 墨玉 |
| 卡通 | 糖果色圆角棋盘、高光棋子 | 糖果 |
| 现代 | 极简玻璃桌面、细线棋盘 | 玻璃 |

菜单「桌面风格」里还有棋院 / 暗夜 / 高对比，以及墨玉、糖果、玻璃、经典玉石、霓虹、木纹、扁平棋子皮肤。选过的皮肤会记住。

## 用 IntelliJ IDEA 打开

1. `File` → `Open`，选择本仓库根目录（识别为 Maven 项目 `gomoku-idea`）。
2. 等待依赖索引完成。
3. 打开 `src/main/java/com/gomoku/GomokuApp.java`，点击行号旁绿色运行按钮，或 `Run` → `Run 'GomokuApp'`。
4. 也可在终端：`mvn -q test` 然后 `mvn -q exec:java`。

主类：`com.gomoku.GomokuApp`（Java 17+）。

## 打包

```bash
chmod +x scripts/package.sh
./scripts/package.sh
```

或执行 `mvn -DskipTests package`。产物在 `target/`：

| 文件 | 说明 |
|------|------|
| `gomoku-idea-1.0.0.jar` | 可直接 `java -jar` 运行 |
| `gomoku-idea-1.0.0-bin.zip` | 运行包：jar + `run.sh` / `run.bat` |
| `gomoku-idea-1.0.0-src.zip` | 源码包：解压后用 IntelliJ 打开 `gomoku-idea` 目录 |

需要本机已安装 **JDK 17 或更高**。

## 已实现功能

- 双人对战、人机对战（堵活四 / 冲活三，难度分级，开局库，浅层搜索）
- 悔棋（可限制次数）、认输、和棋、倒计时、落子确认
- 禁手 + 禁手提示 + 禁手演示
- 棋盘 9/11/13/15/19、让先 / 让二子、三手交换、贴目（满盘贴目判白胜）
- 落子动画、音效、涟漪特效
- 棋谱保存 / 本地云存档 / 打谱回放 / 复盘标注 / 棋风分析
- 残局库与死活题、盲棋（只显示最后几手）
- 联网房间（创建/加入）、观战、聊天
- 评分 Elo 与本地排行榜
- 桌面皮肤：古风 / 卡通 / 现代（另有棋院、暗夜、高对比），棋子皮肤可单独换
- 自对弈训练统计（`SelfPlayTrainer`）

## 目录

```
src/main/java/com/gomoku/     主程序与界面
src/test/java/com/gomoku/     规则与 AI 单测
```
